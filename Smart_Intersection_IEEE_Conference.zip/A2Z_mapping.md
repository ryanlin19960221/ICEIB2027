# A–Z manuscript crosswalk

Based on page 1 of **A2Z outline example.pdf**. Section titles match the IEEE manuscript. F, U and Y are reserved for pending findings.

| Item | Source purpose | Manuscript location and treatment |
|---|---|---|
| A | Attention getter | Abstract opens with waiting-zone encroachment. |
| B | But | Abstract identifies the gap in aggregate counts. |
| C | Cure | Abstract introduces the three-layer framework. |
| D | Development | Abstract names tracking, projection, metrics and retrieval. |
| E | Experiments | Abstract describes the planned two-site validation. |
| F | Findings | Abstract states that field measurements and ratings are pending. |
| G | General | Introduction explains two-stage turning. |
| H | However | Introduction describes overflow and secondary interactions. |
| I | In literature | Introduction moves from crash records and counts to video and retrieval. |
| J | Judgement | Introduction describes the limits of totals and the need for engineering evidence. |
| K | Keypoint | Introduction lists the three contributions. |
| L | List organization | Introduction ends with the paper roadmap. |
| M | Methods | Related Work reviews perception, conflict methods and RAG. |
| N | New proposed | Related Work identifies the shared evidence record. |
| O | Organize | Related Work summarizes four method groups across five columns in Table I. |
| P | Proposed Scheme | Section III and the PA–PM rows below. |
| Q | Quality and quantity | Evaluation Plan specifies sample coverage, annotations and metrics. |
| R | Related methods | Evaluation Plan compares baselines and ablations. |
| S | Simulation setup | Evaluation Plan specifies the field protocol. The Conclusion places SUMO calibration in future work. |
| T | Tuning parameters | Proposed Scheme and Evaluation Plan define provisional values and a development split. |
| U | Useful results | Evaluation Plan lists planned outputs and targets. Measurements are pending. |
| V | Verify effectiveness | Evaluation Plan specifies agreement, ground truth and independent review. |
| W | What proposed | Conclusion recaps the assessment framework. |
| X | eXcel | Conclusion describes the intended review use and relevant operating limits. |
| Y | Yields | Conclusion identifies the evidence to be produced. Empirical findings are pending. |
| Z | Zen | Conclusion outlines future calibration and comparative evaluation. |

## P details

| Item | Source purpose | Manuscript location and treatment |
|---|---|---|
| PA | Aim | Introduction and §III describe reproducible site assessment. |
| PB | Background and focus | §III-A describes engineering priorities and trade-offs. |
| PC | Cure and cause | §III-B–E link phase-aware measurements to candidate treatments. |
| PD | Design | §III and the architecture figure show the three layers and engineering review. |
| PE | Elements | §III-B–E describe perception, spatial analytics and the agent. |
| PF | Formulation | §III-B–D give the projection, capacity, OI and conflict definitions. |
| PG | Graph | Architecture and decision-flow figures under figures/. |
| PH | How | §III-B–E describe calibration, dwell, aggregation and retrieval. |
| PI | Implementation and interaction | §III-D provides numbered pseudocode and a decision flow. |
| PJ | Example | §III-C contains a synthetic calculation labeled as such. |
| PK | Key contributions | Introduction and §III-C–E state the measurement and traceability contributions. |
| PL | Later simulation | §IV and §V describe the field validation and later calibrated SUMO comparison. |
| PM | Mathematical proof | §III-C proves the OI bounds. Empirical validity remains a test objective. |

## Traffic engineering questions from the proposal

| Question | Treatment |
|---|---|
| Why can spillover induce braking or lateral drift? | §I gives the mechanism. §III-D compares matched trajectories. |
| What if glare, rain or reflections destabilize the BEV? | §III-B–C use quality flags and dwell. §IV stratifies by conditions. |
| How should capacity and safety be weighed when narrowing lanes? | §III-A and §IV compare geometry, delay, passing flow and conflicts. |
| How can ordinary queues or unrelated stops be excluded? | §III-C combines movement, synchronized phase and dwell. |
| Why use ByteTrack? | §II describes its low-score association and the need for local validation. |
| What is feasible at narrow intersections? | §III-E screens available width and signal alternatives with an engineer. |
| What evidence should an engineer see? | §III-C–E define percentiles, exposure-normalized events, offsets and evidence records. |
| How do field observations and simulation relate? | §IV plans field validation. §V proposes calibrated simulation for comparing alternatives. |
| How should conflicting regulations and guidance be handled? | §III-E uses versioned evidence, authority filters and unresolved checks. |
| How can calibration work with worn markings? | §III-B uses surveyed, stationary road-plane landmarks and holdout checks. |
