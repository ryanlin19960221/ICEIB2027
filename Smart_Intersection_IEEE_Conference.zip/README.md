# Smart Intersection Evaluation System

IEEEtran A4 conference manuscript in English. Research proposal and planned evaluation.

## Open in Overleaf

1. Choose **New Project → Upload Project** and select the ZIP as downloaded.
2. In project settings, select **main.tex** as the main document and **pdfLaTeX** as the compiler.
3. Select **Recompile**. Overleaf runs BibTeX as part of the build. The project uses standard TeX Live packages and requires no shell escape or external images.
4. Confirm author name romanization and add affiliations before submission. Verify the target ICEIB edition's template, page limit, and anonymization rules.

To build locally with TeX Live, run `latexmk -pdf -halt-on-error main.tex` from the project root.

| File | Purpose |
|---|---|
| main.tex | IEEEtran conference manuscript |
| references.bib | IEEE-style bibliography database |
| figures/architecture.tex | Editable system architecture |
| figures/flow.tex | Editable decision flow |
| algorithm.tex | Line-numbered pseudocode |
| A2Z_mapping.md | A–Z and PA–PM crosswalk and the ten engineering questions |

## Source integration

- **A2Z outline example.pdf**, p. 1 supplies the A–Z and PA–PM labels.
- **smart-intersection-evaluation-proposal.docx**, chapters 1–6 supply the motivation, literature, engineering questions, models, field protocol and future work.
- **smart-intersection-evaluation-presentation.pptx**, slides 7–11 supply the architecture, workflow, report concepts and quantitative planning targets.
- **智慧路口評估系統.pdf**, pp. 1–3 supplies the proposal-to-outline assessment and the domain priorities, trade-offs and phased intervention summary.

The sources give different spillover conditions, including a capacity-or-buffer index and a strict capacity-and-buffer flag. This manuscript uses a phase-gated at-capacity plus qualifying-buffer definition for its primary index, with capacity exceedance and buffer intrusion separately reported. It weights valid intervals by duration and screens adjacent-lane conflicts in eligible spillover and comparison periods. These choices are proposed methods that require validation.

## Pending verification

- The official database identifies Article 191 with two-stage turning-box markings and Article 174 with vehicle-class exclusive lane markings. Confirm the applicable effective versions, municipal requirements, and the legal authority for each proposed action before using recommendations.
- Confirm the issuing agency, title, edition and applicable sections of the pedestrian-oriented design guidance. The source's claimed 2023 agency RAG precedent, lane width mandates, trial effect sizes and a universal 1.5-second PET cutoff are pending primary-source verification. They are excluded as evidence in the manuscript.
- Source-slide dashboard figures, numerical outcomes, timing changes and geometry values are illustrative or unverified. The only worked result in the manuscript is explicitly synthetic. Planning targets are labeled separately from empirical outcomes.
- Author names in the manuscript use provisional romanization for 吳奕霆 and 林丞斌. Field data, SUMO tests and expert evaluation remain pending.
